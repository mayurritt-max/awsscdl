# Text File Word Counter

## Description
This is a simple Python project that counts the number of words in a text file.

## How to Run
1. Run main.py
2. Enter file name (example: sample.txt)

## Technologies Used
- Python

## Example
Input: sample.txt  
Output: Word Count: 7
