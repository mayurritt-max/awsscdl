def count_words(file_path):
    try:
        with open(file_path, 'r') as file:
            text = file.read()
            words = text.split()
            return len(words)
    except FileNotFoundError:
        return "File not found!"

if __name__ == "__main__":
    file_name = input("Enter file name: ")
    result = count_words(file_name)
    print("Word Count:", result)
